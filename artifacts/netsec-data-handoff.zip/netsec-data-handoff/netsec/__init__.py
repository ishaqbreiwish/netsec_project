"""Reproducible security-header measurement."""
